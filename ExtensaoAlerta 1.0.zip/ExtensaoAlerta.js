define(['jquery'], function($) {
  'use strict';

  // Variáveis globais para controlar a piscada
  window.kpiBlinkInterval = window.kpiBlinkInterval || null;

  return {
    definition: {
      type: "items",
      component: "accordion",
      items: {
        settings: {
          uses: "settings",
          items: {
            kpiIds: {
              type: "string",
              label: "IDs dos KPIs (separados por vírgula)",
              ref: "kpiIds",
              defaultValue: "",
              expression: "optional"
            },
            corParaPiscar: {
              type: "string",
              component: "dropdown",
              label: "Piscar quando a cor for:",
              ref: "corParaPiscar",
              options: [
                { value: "todas", label: "Todas as cores (sempre piscar)" },
                { value: "vermelho", label: "Vermelho" },
                { value: "verde", label: "Verde" },
                { value: "amarelo", label: "Amarelo" },
                { value: "azul", label: "Azul" },
                { value: "laranja", label: "Laranja" },
                { value: "custom", label: "Cor personalizada (RGB/HEX)" }
              ],
              defaultValue: "todas"
            },
            corCustomizada: {
              type: "string",
              label: "Cor personalizada (ex: rgb(255,0,0) ou #FF0000)",
              ref: "corCustomizada",
              defaultValue: "",
              show: function(layout) {
                return layout.corParaPiscar === "custom";
              }
            },
            velocidade: {
              type: "number",
              label: "Velocidade da piscada (ms)",
              ref: "velocidade",
              defaultValue: 500
            },
            opacidadeMinima: {
              type: "number",
              label: "Opacidade mínima (0 a 1)",
              ref: "opacidadeMinima",
              defaultValue: 0.2
            }
          }
        }
      }
    },

    paint: function($element, layout) {
      var kpiIds = layout.kpiIds ? layout.kpiIds.split(',').map(function(id) { return id.trim(); }) : [];
      var corParaPiscar = layout.corParaPiscar || 'todas';
      var corCustomizada = layout.corCustomizada || '';
      var velocidade = layout.velocidade || 500;
      var opacidadeMinima = layout.opacidadeMinima || 0.2;
      
      // Mostrar status
      var statusHtml = '<div style="padding:15px; background:#27ae60; color:white; border-radius:5px;">' +
        '<div style="font-weight:bold; font-size:16px; margin-bottom:10px;">✅ KPI Piscante Ativo</div>' +
        '<div style="background:rgba(0,0,0,0.2); padding:10px; border-radius:3px; font-size:12px;">' +
        '<strong>IDs:</strong> ' + (kpiIds.length > 0 ? kpiIds.join(', ') : 'Nenhum') + '<br>' +
        '<strong>Cor:</strong> ' + corParaPiscar + (corParaPiscar === 'custom' ? ' (' + corCustomizada + ')' : '') + '<br>' +
        '<strong>Velocidade:</strong> ' + velocidade + 'ms<br>' +
        '<strong>Opacidade:</strong> ' + opacidadeMinima +
        '</div></div>';
      
      $element.html(statusHtml);
      
      // Parar intervalo anterior
      if (window.kpiBlinkInterval) {
        clearInterval(window.kpiBlinkInterval);
        window.kpiBlinkInterval = null;
      }
      
      // Função para verificar se a cor corresponde
      function verificarCor(elemento, corAlvo) {
        if (corAlvo === 'todas') return true;
        
        var corElemento = window.getComputedStyle(elemento).backgroundColor;
        
        // Mapa de cores
        var cores = {
          'vermelho': ['rgb(255, 0, 0)', 'rgb(220, 53, 69)', 'rgb(244, 67, 54)', 'rgb(211, 47, 47)'],
          'verde': ['rgb(0, 255, 0)', 'rgb(40, 167, 69)', 'rgb(76, 175, 80)', 'rgb(46, 125, 50)'],
          'amarelo': ['rgb(255, 255, 0)', 'rgb(255, 193, 7)', 'rgb(251, 192, 45)'],
          'azul': ['rgb(0, 0, 255)', 'rgb(0, 123, 255)', 'rgb(33, 150, 243)', 'rgb(25, 118, 210)'],
          'laranja': ['rgb(255, 165, 0)', 'rgb(255, 152, 0)', 'rgb(251, 140, 0)']
        };
        
        if (corAlvo === 'custom') {
          // Converter cor customizada para RGB
          var tempDiv = document.createElement('div');
          tempDiv.style.color = corCustomizada;
          document.body.appendChild(tempDiv);
          var corConvertida = window.getComputedStyle(tempDiv).color;
          document.body.removeChild(tempDiv);
          return corElemento === corConvertida;
        }
        
        // Verificar se a cor do elemento está na lista de cores alvo
        var coresAlvo = cores[corAlvo] || [];
        return coresAlvo.some(function(cor) {
          return corElemento.indexOf(cor) !== -1 || cor.indexOf(corElemento) !== -1;
        });
      }
      
      // Variável para controlar visibilidade
      var isVisible = true;
      
      // Iniciar intervalo de piscada
      window.kpiBlinkInterval = setInterval(function() {
        kpiIds.forEach(function(kpiId) {
          if (!kpiId) return;
          
          // Buscar o KPI usando vários seletores
          var kpiElement = document.querySelector('article[tid="' + kpiId + '"]') || 
                          document.querySelector('[tid="' + kpiId + '"]') ||
                          document.querySelector('article[data-qlik-id="' + kpiId + '"]') ||
                          document.querySelector('[data-qlik-id="' + kpiId + '"]');
          
          if (kpiElement) {
            // Verificar se a cor corresponde antes de piscar
            if (verificarCor(kpiElement, corParaPiscar)) {
              kpiElement.style.opacity = isVisible ? opacidadeMinima : '1';
              kpiElement.style.transition = 'opacity 0.3s';
            }
          } else {
            // Busca alternativa
            var kpis = document.querySelectorAll('.qv-object-kpi');
            kpis.forEach(function(kpi) {
              var article = kpi.closest('article');
              if (article) {
                var tid = article.getAttribute('tid') || article.getAttribute('data-qlik-id');
                if (tid === kpiId && verificarCor(article, corParaPiscar)) {
                  article.style.opacity = isVisible ? opacidadeMinima : '1';
                  article.style.transition = 'opacity 0.3s';
                }
              }
            });
          }
        });
        
        isVisible = !isVisible;
      }, velocidade);
      
      console.log('✅ Extensão ativada | IDs:', kpiIds, '| Cor:', corParaPiscar, '| Velocidade:', velocidade + 'ms');
      
      return;
    },
    
    destroy: function() {
      if (window.kpiBlinkInterval) {
        clearInterval(window.kpiBlinkInterval);
        window.kpiBlinkInterval = null;
        
        // Restaurar opacidade dos elementos
        var allArticles = document.querySelectorAll('article[tid], [data-qlik-id]');
        allArticles.forEach(function(el) {
          el.style.opacity = '1';
        });
        
        console.log('❌ Extensão KPI Piscante desativada');
      }
    }
  };
});
