define(['jquery'], function($) {
  'use strict';

  window.kpiBlinkInterval = window.kpiBlinkInterval || null;

  return {
    definition: {
      type: "items",
      component: "accordion",
      items: {
        settings: {
          uses: "settings",
          items: {
            kpiIds: {
              type: "string",
              label: "IDs dos KPIs (separados por vírgula)",
              ref: "kpiIds",
              defaultValue: "",
              expression: "optional"
            },
            corParaPiscar: {
              type: "string",
              component: "dropdown",
              label: "Piscar quando a cor for:",
              ref: "corParaPiscar",
              options: [
                { value: "todas", label: "Todas as cores (sempre piscar)" },
                { value: "vermelho", label: "Vermelho" },
                { value: "verde", label: "Verde" },
                { value: "amarelo", label: "Amarelo" },
                { value: "azul", label: "Azul" },
                { value: "laranja", label: "Laranja" },
                { value: "custom", label: "Cor personalizada (RGB/HEX)" }
              ],
              defaultValue: "todas"
            },
            corCustomizada: {
              type: "string",
              label: "Cor personalizada (ex: rgb(255,0,0) ou #FF0000)",
              ref: "corCustomizada",
              defaultValue: "",
              show: function(layout) {
                return layout.corParaPiscar === "custom";
              }
            },
            velocidade: {
              type: "number",
              label: "Velocidade da piscada (ms)",
              ref: "velocidade",
              defaultValue: 500
            },
            opacidadeMinima: {
              type: "number",
              label: "Opacidade mínima (0 a 1)",
              ref: "opacidadeMinima",
              defaultValue: 0.2
            },
            modoDebug: {
              type: "boolean",
              label: "Modo Debug (mostrar cores no console)",
              ref: "modoDebug",
              defaultValue: false
            }
          }
        }
      }
    },

    paint: function($element, layout) {
      var kpiIds = layout.kpiIds ? layout.kpiIds.split(',').map(function(id) { return id.trim(); }) : [];
      var corParaPiscar = layout.corParaPiscar || 'todas';
      var corCustomizada = layout.corCustomizada || '';
      var velocidade = layout.velocidade || 500;
      var opacidadeMinima = layout.opacidadeMinima || 0.2;
      var modoDebug = layout.modoDebug || false;
      
      // Mostrar status
      var statusHtml = '<div style="padding:15px; background:#27ae60; color:white; border-radius:5px;">' +
        '<div style="font-weight:bold; font-size:16px; margin-bottom:10px;">✅ KPI Piscante Ativo</div>' +
        '<div style="background:rgba(0,0,0,0.2); padding:10px; border-radius:3px; font-size:12px;">' +
        '<strong>IDs:</strong> ' + (kpiIds.length > 0 ? kpiIds.join(', ') : 'Nenhum') + '<br>' +
        '<strong>Cor:</strong> ' + corParaPiscar + (corParaPiscar === 'custom' ? ' (' + corCustomizada + ')' : '') + '<br>' +
        '<strong>Velocidade:</strong> ' + velocidade + 'ms<br>' +
        '<strong>Opacidade:</strong> ' + opacidadeMinima + '<br>' +
        '<strong>Debug:</strong> ' + (modoDebug ? 'ON' : 'OFF') +
        '</div></div>';
      
      $element.html(statusHtml);
      
      // Parar intervalo anterior
      if (window.kpiBlinkInterval) {
        clearInterval(window.kpiBlinkInterval);
        window.kpiBlinkInterval = null;
      }
      
      // Função para normalizar cor RGB
      function normalizarCor(cor) {
        if (!cor) return '';
        // Remove espaços extras e converte para minúsculas
        return cor.replace(/\s+/g, '').toLowerCase();
      }
      
      // Função para converter HEX para RGB
      function hexParaRgb(hex) {
        var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? 
          'rgb(' + parseInt(result[1], 16) + ',' + parseInt(result[2], 16) + ',' + parseInt(result[3], 16) + ')' : 
          null;
      }
      
      // Função para buscar cor em todos os elementos do KPI
      function buscarCoresNoKPI(elemento) {
        var cores = [];
        
        // Cor do próprio elemento
        var corElemento = window.getComputedStyle(elemento).backgroundColor;
        if (corElemento && corElemento !== 'rgba(0, 0, 0, 0)' && corElemento !== 'transparent') {
          cores.push(normalizarCor(corElemento));
        }
        
        // Buscar cores em elementos internos (onde geralmente fica a cor do KPI)
        var seletores = [
          '.qv-object-kpi',
          '.kpi-value',
          '.qv-inner-object',
          'div[style*="background"]',
          'span[style*="background"]',
          '.kpi',
          '[class*="color"]',
          '[class*="background"]'
        ];
        
        seletores.forEach(function(seletor) {
          var elementos = elemento.querySelectorAll(seletor);
          elementos.forEach(function(el) {
            var bg = window.getComputedStyle(el).backgroundColor;
            if (bg && bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent') {
              cores.push(normalizarCor(bg));
            }
            // Verificar também a cor do texto
            var color = window.getComputedStyle(el).color;
            if (color && color !== 'rgba(0, 0, 0, 0)' && color !== 'transparent') {
              cores.push(normalizarCor(color));
            }
          });
        });
        
        // Buscar em todos os divs filhos
        var todosOsDivs = elemento.querySelectorAll('div, span');
        for (var i = 0; i < Math.min(todosOsDivs.length, 20); i++) {
          var el = todosOsDivs[i];
          var bg = window.getComputedStyle(el).backgroundColor;
          if (bg && bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent') {
            cores.push(normalizarCor(bg));
          }
        }
        
        return cores;
      }
      
      // Função para verificar se a cor corresponde
      function verificarCor(elemento, corAlvo, kpiId) {
        if (corAlvo === 'todas') return true;
        
        var coresEncontradas = buscarCoresNoKPI(elemento);
        
        if (modoDebug) {
          console.log('🔍 Debug KPI:', kpiId);
          console.log('Cores encontradas:', coresEncontradas);
        }
        
        // Mapa de cores predefinidas (normalizadas)
        var cores = {
          'vermelho': [
            'rgb(255,0,0)', 'rgb(220,53,69)', 'rgb(244,67,54)', 
            'rgb(211,47,47)', 'rgb(229,57,53)', 'rgb(239,83,80)',
            'rgb(255,82,82)', 'rgb(198,40,40)'
          ],
          'verde': [
            'rgb(0,255,0)', 'rgb(40,167,69)', 'rgb(76,175,80)', 
            'rgb(46,125,50)', 'rgb(67,160,71)', 'rgb(102,187,106)',
            'rgb(76,217,100)', 'rgb(52,168,83)'
          ],
          'amarelo': [
            'rgb(255,255,0)', 'rgb(255,193,7)', 'rgb(251,192,45)',
            'rgb(255,235,59)', 'rgb(253,216,53)'
          ],
          'azul': [
            'rgb(0,0,255)', 'rgb(0,123,255)', 'rgb(33,150,243)', 
            'rgb(25,118,210)', 'rgb(30,136,229)', 'rgb(66,165,245)'
          ],
          'laranja': [
            'rgb(255,165,0)', 'rgb(255,152,0)', 'rgb(251,140,0)',
            'rgb(255,167,38)', 'rgb(251,192,45)'
          ]
        };
        
        var corAlvoNormalizada = '';
        
        if (corAlvo === 'custom') {
          // Normalizar cor customizada
          var corTemp = corCustomizada;
          if (corTemp.indexOf('#') === 0) {
            corTemp = hexParaRgb(corTemp);
          }
          corAlvoNormalizada = normalizarCor(corTemp);
          
          if (modoDebug) {
            console.log('Cor customizada normalizada:', corAlvoNormalizada);
          }
          
          return coresEncontradas.some(function(cor) {
            return cor === corAlvoNormalizada;
          });
        }
        
        // Verificar cores predefinidas
        var coresAlvo = (cores[corAlvo] || []).map(normalizarCor);
        
        if (modoDebug) {
          console.log('Cores alvo:', coresAlvo);
        }
        
        return coresEncontradas.some(function(corEncontrada) {
          return coresAlvo.indexOf(corEncontrada) !== -1;
        });
      }
      
      // Variável para controlar visibilidade
      var isVisible = true;
      
      // Iniciar intervalo de piscada
      window.kpiBlinkInterval = setInterval(function() {
        kpiIds.forEach(function(kpiId) {
          if (!kpiId) return;
          
          // Buscar o KPI usando vários seletores
          var kpiElement = document.querySelector('article[tid="' + kpiId + '"]') || 
                          document.querySelector('[tid="' + kpiId + '"]') ||
                          document.querySelector('article[data-qlik-id="' + kpiId + '"]') ||
                          document.querySelector('[data-qlik-id="' + kpiId + '"]');
          
          if (kpiElement) {
            // Verificar se a cor corresponde antes de piscar
            if (verificarCor(kpiElement, corParaPiscar, kpiId)) {
              kpiElement.style.opacity = isVisible ? opacidadeMinima : '1';
              kpiElement.style.transition = 'opacity 0.3s';
            }
          } else {
            // Busca alternativa
            var kpis = document.querySelectorAll('.qv-object-kpi');
            kpis.forEach(function(kpi) {
              var article = kpi.closest('article');
              if (article) {
                var tid = article.getAttribute('tid') || article.getAttribute('data-qlik-id');
                if (tid === kpiId && verificarCor(article, corParaPiscar, kpiId)) {
                  article.style.opacity = isVisible ? opacidadeMinima : '1';
                  article.style.transition = 'opacity 0.3s';
                }
              }
            });
          }
        });
        
        isVisible = !isVisible;
      }, velocidade);
      
      console.log('✅ Extensão ativada | IDs:', kpiIds, '| Cor:', corParaPiscar, '| Velocidade:', velocidade + 'ms');
      
      return;
    },
    
    destroy: function() {
      if (window.kpiBlinkInterval) {
        clearInterval(window.kpiBlinkInterval);
        window.kpiBlinkInterval = null;
        
        // Restaurar opacidade dos elementos
        var allArticles = document.querySelectorAll('article[tid], [data-qlik-id]');
        allArticles.forEach(function(el) {
          el.style.opacity = '1';
        });
        
        console.log('❌ Extensão KPI Piscante desativada');
      }
    }
  };
});
